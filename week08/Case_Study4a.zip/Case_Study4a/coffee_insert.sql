use javajam;

insert into coffee values
  (1,  "Just_Java", 2.00,0),
  (2,  "Cafe_au_Lait", 2.00,0),
  (3,  "Cafe_au_Lait", 3.00,1),
  (4,  "Iced_Capuccino", 4.50,0),
  (5,  "Iced_Capuccino", 5.50,1);



